//This file contains the Google API Client key (Using Wilbur's account) for including 
//Google's OAuth functionalities
module.exports = {
    'googleAuth' : {
        'clientID'      : '547659251063-pelct1d1qkr8e88b43dcic17ue5dnudm.apps.googleusercontent.com',
        'clientSecret'  : '4jVXbSZRSrB8qARvxXjim2LJ',
        'callbackURL'   : '/auth/google/callback'
    }
};