//This file contains the Google API Client key (Using Wilbur's account) for including 
//Google's OAuth functionalities
module.exports = {
    'googleAuth' : {
        'clientID'      : '547659251063-i9ua0he2m29lpbqr0k1oe6e37r0ummr8.apps.googleusercontent.com',
        'clientSecret'  : 'HnrzTI4Jy21XIHS747XUbey8',
        'callbackURL'   : 'http://localhost:3000/auth/google/callback'
    }
};